import type { Metadata } from "next";
import "./game.css";

export const metadata: Metadata = {
  title: "Growth Mission — доведи эксперимент до решения",
  description: "Командная игра для Zoom: ведущий, синхронные раунды, решения и статистика экспериментов.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}
