// Schema declarations live in schema.ts; application logic uses bounded D1 statements.
export const DECK_VERSION = 'ab-2.3-live-1';
